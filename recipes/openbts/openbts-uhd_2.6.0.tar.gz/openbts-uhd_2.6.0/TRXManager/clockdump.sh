#!/bin/sh
sudo tcpdump -i lo0 -A udp port 5700


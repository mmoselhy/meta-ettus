#!/bin/sh

# A script to restart and just keep OpenBTS running.
while true; do killall transceiver; sleep 2; ./OpenBTS; done

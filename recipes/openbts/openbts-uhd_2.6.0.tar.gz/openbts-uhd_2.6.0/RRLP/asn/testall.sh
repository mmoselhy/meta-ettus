#!/bin/bash
erl -noshell -s testall run -s erlang halt


#include <RRLPMessages.h>

int main()
{
    // this should just compile, will probably segfault when run
    RRLP::RRLPQuery(NULL);
    return 0;
}


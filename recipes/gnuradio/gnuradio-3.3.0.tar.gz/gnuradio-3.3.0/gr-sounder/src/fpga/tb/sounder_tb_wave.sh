#!/bin/sh
gtkwave sounder_tb.vcd sounder_tb.sav

#!/bin/sh

# Note this runs the installed script, not the one in the tree
usrp_sounder.py -r -l -t -d12 -v -F loopback.dat -D

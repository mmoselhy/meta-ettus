#!/bin/sh
gtkwave radar_tb.vcd radar_tb.sav
